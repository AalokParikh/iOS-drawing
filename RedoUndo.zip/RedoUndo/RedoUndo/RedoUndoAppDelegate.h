//
//  RedoUndoAppDelegate.h
//  RedoUndo
//
//  Created by Reetu Raj on 31/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrawingController.h"

@interface RedoUndoAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
