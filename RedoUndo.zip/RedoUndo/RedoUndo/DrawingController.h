//
//  DrawingController.h
//  DrawLines
//
//  Created by Reetu Raj on 11/05/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyLineDrawingView.h"


@interface DrawingController : UIViewController {
    
    MyLineDrawingView *drawScreen;

    
}

@end
